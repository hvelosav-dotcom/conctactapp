# Luffy (Android · Java)

Pequeña app de ejemplo con 3 pantallas en **Material Design**.

## Estructura
- `MainActivity` (Inicio con botones)
- `CatalogActivity` (lista simple)
- `ContactActivity` (información de contacto)
- Paleta de colores extraída del logo.

## Cómo abrir en Android Studio
1. `File > Open...` y selecciona la carpeta `LuffyAppJava`.
2. Espera a que Gradle sincronice.
3. Ejecuta en un emulador o dispositivo físico.

## Subir a GitHub (rápido)
1. Crea un repositorio en GitHub (público o privado).
2. Sube esta carpeta tal cual (Arrastrar y soltar en la web de GitHub).
3. Agrega los pantallazos en la carpeta `/screens`.

## Pantallazos
- Home: `screens/home.png`
- Catálogo: `screens/catalog.png`
- Contacto: `screens/contact.png`

---
Colores:
- Primario: #75E1E8
- Secundario: #4D3F43
