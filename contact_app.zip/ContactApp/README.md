ContactApp - Android Studio project skeleton (Java, Material Design)

Instrucciones:
1. Abre Android Studio -> Open -> selecciona la carpeta 'ContactApp' (el módulo app está dentro).
2. Espera a que sincronice Gradle.
3. Ejecuta en un emulador o dispositivo.

Contenido:
- 2 Activities en Java: FormularioActivity y ConfirmacionActivity
- Layouts con TextInputLayout/TextInputEditText para estilo Material
- DatePicker para seleccionar fecha
- Botón editar que vuelve al formulario con datos precargados

Archivos generados automáticamente para la entrega de la tarea.
