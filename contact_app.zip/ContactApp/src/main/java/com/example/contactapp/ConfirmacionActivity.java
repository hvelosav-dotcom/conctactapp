package com.example.contactapp;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

public class ConfirmacionActivity extends AppCompatActivity {
    TextView tvDatos;
    Button btnEditar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_confirmacion);

        tvDatos = findViewById(R.id.tvDatos);
        btnEditar = findViewById(R.id.btnEditar);

        Intent intent = getIntent();
        String nombre = intent.getStringExtra("nombre");
        String fecha = intent.getStringExtra("fecha");
        String telefono = intent.getStringExtra("telefono");
        String email = intent.getStringExtra("email");
        String descripcion = intent.getStringExtra("descripcion");

        String texto = "Nombre: " + (nombre != null ? nombre : "") + "\n"
                + "Fecha de nacimiento: " + (fecha != null ? fecha : "") + "\n"
                + "Teléfono: " + (telefono != null ? telefono : "") + "\n"
                + "Email: " + (email != null ? email : "") + "\n"
                + "Descripción: " + (descripcion != null ? descripcion : "");

        tvDatos.setText(texto);

        btnEditar.setOnClickListener(v -> {
            Intent i = new Intent(this, FormularioActivity.class);
            i.putExtra("nombre", nombre);
            i.putExtra("fecha", fecha);
            i.putExtra("telefono", telefono);
            i.putExtra("email", email);
            i.putExtra("descripcion", descripcion);
            startActivity(i);
            finish();
        });
    }
}
