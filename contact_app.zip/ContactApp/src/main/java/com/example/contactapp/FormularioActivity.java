package com.example.contactapp;

import androidx.appcompat.app.AppCompatActivity;
import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import com.google.android.material.textfield.TextInputEditText;
import java.util.Calendar;

public class FormularioActivity extends AppCompatActivity {
    TextInputEditText etNombre, etTelefono, etEmail, etDescripcion;
    Button btnFecha, btnSiguiente;
    String fechaNacimiento = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_formulario);

        etNombre = findViewById(R.id.etNombre);
        etTelefono = findViewById(R.id.etTelefono);
        etEmail = findViewById(R.id.etEmail);
        etDescripcion = findViewById(R.id.etDescripcion);
        btnFecha = findViewById(R.id.btnFecha);
        btnSiguiente = findViewById(R.id.btnSiguiente);

        // Recuperar datos si vienen de Editar
        if(getIntent().hasExtra("nombre")){
            etNombre.setText(getIntent().getStringExtra("nombre"));
            fechaNacimiento = getIntent().getStringExtra("fecha");
            btnFecha.setText(fechaNacimiento);
            etTelefono.setText(getIntent().getStringExtra("telefono"));
            etEmail.setText(getIntent().getStringExtra("email"));
            etDescripcion.setText(getIntent().getStringExtra("descripcion"));
        }

        btnFecha.setOnClickListener(v -> {
            Calendar c = Calendar.getInstance();
            DatePickerDialog dp = new DatePickerDialog(this, (view, year, month, day) -> {
                fechaNacimiento = day + "/" + (month+1) + "/" + year;
                btnFecha.setText(fechaNacimiento);
            }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH));
            dp.show();
        });

        btnSiguiente.setOnClickListener(v -> {
            Intent intent = new Intent(this, ConfirmacionActivity.class);
            intent.putExtra("nombre", etNombre.getText().toString());
            intent.putExtra("fecha", fechaNacimiento);
            intent.putExtra("telefono", etTelefono.getText().toString());
            intent.putExtra("email", etEmail.getText().toString());
            intent.putExtra("descripcion", etDescripcion.getText().toString());
            startActivity(intent);
        });
    }
}
